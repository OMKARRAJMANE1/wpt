const express=require("express");
const router=express.Router();
const connection=require("../db/dbconnections");

router.get("/candidates",(req,resp)=>{
    connection.query("select * from candidates",(err,data)=>{
        if(err){
            resp.status(500).send("data not found")
        }
        else{
            resp.status(200).send(data)
        }
    })
})


router.post("/insertcandidate",(req,resp)=>{
    connection.query("insert into candidates values(?,?,?,?)",[req.body.id,req.body.name,req.body.party,req.body.votes],(err)=>{
        if(err)
        resp.status(500).send("data not inserted")
    else{
    resp.status(200).send("data inserted")
    }
    })

})

router.delete("/deletedata/:cid",(req,resp)=>{
    connection.query("delete from candidates where id=?",[req.params.cid],(err)=>{
        if(err)
        resp.status(500).send("data not deleted")
    else{
        resp.status(200).send("data deleted")
    }
    })
})

router.put("/updatedata/:cid",(req,resp)=>{
    connection.query("update candidates set name=?,party=?,votes=? where id=?",[req.body.name,req.body.party,req.body.votes,req.params.cid],(err)=>{
        if(err){
            resp.status(500).send("data not updates")
        }
        else{
            resp.status(200).send("data updated")
        }
    })
})


module.exports=router;