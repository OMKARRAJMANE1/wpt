const express=require("express");
const app=express();
const router=require("./router/routers");
const bodyparser=require("body-parser");
const path=require("path");


app.use(bodyparser.urlencoded({extended:false}))
app.use(bodyparser.json())
app.use("/",router);

app.listen(9000,(err)=>{
    if(err){
        console.log("err occured")
    }
    else{
        console.log("server started at port 9000")
    }
})
module.exports=app;